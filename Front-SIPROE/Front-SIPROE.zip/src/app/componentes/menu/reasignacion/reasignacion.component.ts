import { Component } from '@angular/core';

@Component({
  selector: 'app-reasignacion',
  imports: [],
  templateUrl: './reasignacion.component.html',
  styleUrl: './reasignacion.component.css'
})
export class ReasignacionComponent {

}
