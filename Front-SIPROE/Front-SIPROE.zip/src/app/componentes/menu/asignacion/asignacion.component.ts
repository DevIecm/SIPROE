import { Component } from '@angular/core';

@Component({
  selector: 'app-asignacion',
  imports: [],
  templateUrl: './asignacion.component.html',
  styleUrl: './asignacion.component.css'
})
export class AsignacionComponent {

}
