import { Component } from '@angular/core';

@Component({
  selector: 'app-sorteo',
  imports: [],
  templateUrl: './sorteo.component.html',
  styleUrl: './sorteo.component.css'
})
export class SorteoComponent {

}
